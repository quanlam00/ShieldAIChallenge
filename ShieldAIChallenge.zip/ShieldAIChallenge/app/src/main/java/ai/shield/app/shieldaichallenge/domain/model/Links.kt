package ai.shield.app.shieldaichallenge.domain.model

/**
 * Domain Model of a TV Show's Episode's Guide's Links
 */
data class Links(
    val self: Self
)