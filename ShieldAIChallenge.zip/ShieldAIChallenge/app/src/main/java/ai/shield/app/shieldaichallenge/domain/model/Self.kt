package ai.shield.app.shieldaichallenge.domain.model

/**
 * Domain Model of a TV Show's Episode's Guide's Link's content.
 */
data class Self(
    val href: String
)